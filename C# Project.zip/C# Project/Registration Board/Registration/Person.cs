﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Registration
{
    internal class Person
    {
        public string Name { set; get; }
        public long Academic_Number { set; get; }
        public string Address { set; get; }
        public string Gender { set; get; }
        public DateTime Date_Of_Birth { set; get; }
        public string Emaile { set; get; }
        public string Passwoord { set; get; }
        public string Photo_Path { set; get; }


    }
}
